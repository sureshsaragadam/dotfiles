-- lua/lspm/capabilities.lua

return require("blink.cmp").get_lsp_capabilities()
