-- autopairs
-- https://github.com/windwp/nvim-autopairs

return {
	"windwp/nvim-autopairs",
	enabled = true,
	event = "InsertEnter",
	opts = {},
}
